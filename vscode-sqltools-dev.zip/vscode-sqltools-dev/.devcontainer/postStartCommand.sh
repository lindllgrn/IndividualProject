#!/bin/bash
git config --global --add safe.directory /workspaces/vscode-sqltools

echo 'To build all VSIXes: npm run pack:all'
