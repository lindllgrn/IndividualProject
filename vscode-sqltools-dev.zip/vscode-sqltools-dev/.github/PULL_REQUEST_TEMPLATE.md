Describe here what is this PR about and what we are achieving merging this.

----

Thank you for your contribution! 
Before submitting this PR, please make sure:

- [ ] Your code builds clean without any errors or warnings
- [ ] You have made the needed changes to the docs
- [ ] You have written a description of what is the purpose of this pull request above
