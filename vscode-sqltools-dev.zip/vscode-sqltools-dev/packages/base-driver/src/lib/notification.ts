export const ElectronNotSupportedNotification = 'Core/electronNotSupported';
export const MissingModuleNotification = 'Core/missingModule';
