import { IDriverAlias } from '@sqltools/types';

export const DRIVER_ALIASES: IDriverAlias[] = [
  { displayName: 'SQL Server/Azure', value: 'MSSQL'},
];