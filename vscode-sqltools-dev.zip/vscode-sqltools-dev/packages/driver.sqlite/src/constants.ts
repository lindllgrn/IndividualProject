import { IDriverAlias } from '@sqltools/types';

export const DRIVER_ALIASES: IDriverAlias[] = [
  { displayName: 'SQLite (Node)', value: 'SQLite'},
];