## See https://vscode-sqltools.mteixeira.dev/changelog
