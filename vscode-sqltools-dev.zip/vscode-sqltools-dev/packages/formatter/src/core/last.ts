const last = (arr: any[] = []) => arr[arr.length - 1];

export default last;
