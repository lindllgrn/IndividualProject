export const DriverNotInstalledNotification = 'LS/driverNotInstalled';
export const ExitCalledNotification = 'AutoRestart/exitCalled';
export const ServerErrorNotification = 'Core/errorNotification';
