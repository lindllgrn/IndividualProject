import factory from './factory';

export default factory();