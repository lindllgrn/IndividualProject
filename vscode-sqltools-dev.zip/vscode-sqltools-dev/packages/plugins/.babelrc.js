module.exports = require('../../build-tools/webpack/webview/babelrc')
