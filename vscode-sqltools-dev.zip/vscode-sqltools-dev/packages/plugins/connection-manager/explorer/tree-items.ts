import SidebarConnection from './SidebarConnection';
import SidebarItem from './SidebarItem';

export type SidebarTreeItem = SidebarConnection
| SidebarItem;