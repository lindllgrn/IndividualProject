export enum Step {
  CONNECTION_DRIVER_SELECTOR = 1,
  CONNECTION_FORM = 2,
  CONNECTION_SAVED = 3,
}

export const lastStep = Step.CONNECTION_SAVED;