export default class GenericError extends Error {
}
