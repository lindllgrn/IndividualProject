import GenericError from './generic';
export class NotFoundError extends GenericError { }

export default NotFoundError;
