import GenericError from './generic';

export class SizeError extends GenericError {}
