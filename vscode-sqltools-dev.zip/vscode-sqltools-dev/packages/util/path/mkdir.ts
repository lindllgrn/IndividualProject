import * as mkdir from 'make-dir';

export default mkdir;