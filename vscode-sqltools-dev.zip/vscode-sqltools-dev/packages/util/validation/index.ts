export function isEmpty(v?: string | any[]) {
  return !v || v.length === 0;
}