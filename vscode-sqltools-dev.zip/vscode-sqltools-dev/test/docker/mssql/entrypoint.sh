bash /import-data.sh &
/opt/mssql/bin/sqlservr
