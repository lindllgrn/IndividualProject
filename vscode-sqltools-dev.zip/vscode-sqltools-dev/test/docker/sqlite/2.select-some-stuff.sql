-- @conn SQLite
SELECT 1 as one;

SELECT 2 as two;

SELECT * from contacts;